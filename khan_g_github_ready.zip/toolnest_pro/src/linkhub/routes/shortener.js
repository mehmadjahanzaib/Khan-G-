// CREATE — URL shortener: create short links, view stats, redirect visitors
const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const { requireLogin } = require("../middleware/auth");
const ShortUrl = require("../models/ShortUrl");

// Generates a random 6-character code like "aZ3kLm"
function generateShortCode() {
  return crypto.randomBytes(4).toString("base64url").slice(0, 6);
}

// Show shortener page with user's existing short links
router.get("/dashboard/shortener", requireLogin, async (req, res) => {
  const urls = await ShortUrl.find({ user: req.session.userId }).sort({ createdAt: -1 });
  res.render("shortener", { urls, error: null, siteUrl: req.protocol + "://" + req.get("host") });
});

// Create a new short URL
router.post("/dashboard/shortener", requireLogin, async (req, res) => {
  try {
    const { originalUrl } = req.body;

    if (!originalUrl) {
      const urls = await ShortUrl.find({ user: req.session.userId }).sort({ createdAt: -1 });
      return res.render("shortener", {
        urls,
        error: "URL daalna zaroori hai.",
        siteUrl: req.protocol + "://" + req.get("host"),
      });
    }

    // keep generating a code until we get one that isn't already used
    let shortCode;
    let exists = true;
    while (exists) {
      shortCode = generateShortCode();
      exists = await ShortUrl.findOne({ shortCode });
    }

    await ShortUrl.create({
      user: req.session.userId,
      originalUrl,
      shortCode,
    });

    res.redirect("/linkhub/dashboard/shortener");
  } catch (err) {
    console.error(err);
    res.redirect("/linkhub/dashboard/shortener");
  }
});

// Delete a short URL
router.post("/dashboard/shortener/:id/delete", requireLogin, async (req, res) => {
  try {
    await ShortUrl.deleteOne({ _id: req.params.id, user: req.session.userId });
    res.redirect("/linkhub/dashboard/shortener");
  } catch (err) {
    console.error(err);
    res.redirect("/linkhub/dashboard/shortener");
  }
});

// Public redirect — visiting the short link sends visitor to the real URL
router.get("/s/:code", async (req, res) => {
  const link = await ShortUrl.findOne({ shortCode: req.params.code });

  if (!link) {
    return res.status(404).send("Link not found");
  }

  link.clickCount += 1;
  await link.save();

  res.redirect(link.originalUrl);
});

module.exports = router;
