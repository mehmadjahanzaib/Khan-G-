// CREATE — handles signup, login, logout
const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const User = require("../models/User");

// Show signup page
router.get("/signup", (req, res) => {
  res.render("signup", { error: null });
});

// Handle signup form
router.post("/signup", async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.render("signup", { error: "Sab fields fill karein." });
    }

    const existingUser = await User.findOne({
      $or: [{ email: email.toLowerCase() }, { username: username.toLowerCase() }],
    });

    if (existingUser) {
      return res.render("signup", {
        error: "Ye username ya email pehle se registered hai.",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = await User.create({
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      password: hashedPassword,
    });

    req.session.userId = newUser._id;
    res.redirect("/linkhub/dashboard");
  } catch (err) {
    console.error(err);
    res.render("signup", { error: "Kuch ghalat hogaya, dobara try karein." });
  }
});

// Show login page
router.get("/login", (req, res) => {
  res.render("login", { error: null });
});

// Handle login form
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      return res.render("login", { error: "Email ya password ghalat hai." });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.render("login", { error: "Email ya password ghalat hai." });
    }

    req.session.userId = user._id;
    res.redirect("/linkhub/dashboard");
  } catch (err) {
    console.error(err);
    res.render("login", { error: "Kuch ghalat hogaya, dobara try karein." });
  }
});

// Logout
router.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/linkhub/login");
  });
});

module.exports = router;
