// CREATE — logged-in user's dashboard: add, edit, delete their links
const express = require("express");
const router = express.Router();
const { requireLogin } = require("../middleware/auth");
const User = require("../models/User");
const Link = require("../models/Link");

// Show dashboard with all of the user's links
router.get("/dashboard", requireLogin, async (req, res) => {
  const user = await User.findById(req.session.userId);
  const links = await Link.find({ user: user._id }).sort({ order: 1 });
  res.render("dashboard", { user, links, error: null });
});

// Add a new link
router.post("/dashboard/links", requireLogin, async (req, res) => {
  try {
    const { title, url } = req.body;

    if (!title || !url) {
      const user = await User.findById(req.session.userId);
      const links = await Link.find({ user: user._id }).sort({ order: 1 });
      return res.render("dashboard", {
        user,
        links,
        error: "Title aur URL dono zaroori hain.",
      });
    }

    // IMPLEMENTATION ASSUMPTION: free plan limited to 5 links
    const user = await User.findById(req.session.userId);
    const linkCount = await Link.countDocuments({ user: user._id });

    if (user.plan === "free" && linkCount >= 5) {
      const links = await Link.find({ user: user._id }).sort({ order: 1 });
      return res.render("dashboard", {
        user,
        links,
        error: "Free plan mein sirf 5 links allowed hain. Upgrade karein zyada ke liye.",
      });
    }

    await Link.create({
      user: user._id,
      title,
      url,
      order: linkCount,
    });

    res.redirect("/linkhub/dashboard");
  } catch (err) {
    console.error(err);
    res.redirect("/linkhub/dashboard");
  }
});

// Delete a link
router.post("/dashboard/links/:id/delete", requireLogin, async (req, res) => {
  try {
    await Link.deleteOne({ _id: req.params.id, user: req.session.userId });
    res.redirect("/linkhub/dashboard");
  } catch (err) {
    console.error(err);
    res.redirect("/linkhub/dashboard");
  }
});

module.exports = router;
