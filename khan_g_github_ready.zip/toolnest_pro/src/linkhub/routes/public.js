// CREATE — the public page anyone can visit at yoursite.com/username
const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Link = require("../models/Link");

// Public profile page
router.get("/:username", async (req, res, next) => {
  const user = await User.findOne({ username: req.params.username.toLowerCase() });

  if (!user) {
    return next(); // falls through to 404 if no such username
  }

  const links = await Link.find({ user: user._id }).sort({ order: 1 });
  res.render("publicPage", { profileUser: user, links });
});

// Click tracking — every link on the public page points here first,
// we count the click, then redirect to the real URL
router.get("/l/:linkId", async (req, res) => {
  const link = await Link.findById(req.params.linkId);

  if (!link) {
    return res.redirect("/linkhub");
  }

  link.clickCount += 1;
  await link.save();

  res.redirect(link.url);
});

module.exports = router;
