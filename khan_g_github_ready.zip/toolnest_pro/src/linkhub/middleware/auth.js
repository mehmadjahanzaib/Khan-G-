// CREATE — checks if user is logged in before letting them access the dashboard
function requireLogin(req, res, next) {
  if (!req.session.userId) {
    return res.redirect("/linkhub/login");
  }
  next();
}

module.exports = { requireLogin };
