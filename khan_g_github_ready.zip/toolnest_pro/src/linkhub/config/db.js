// CREATE — connects our app to MongoDB using the connection string in .env
const mongoose = require("mongoose");

async function connectDB() {
  if (!process.env.MONGODB_URI) {
    console.warn("MONGODB_URI not set — LinkHub (/linkhub) will not work until it is configured. The rest of Khan G is unaffected.");
    return;
  }
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("MongoDB connected successfully");
  } catch (err) {
    console.error("MongoDB connection failed:", err.message);
    // Don't crash the whole Khan G server just because LinkHub's DB is unreachable.
  }
}

module.exports = connectDB;
