// LinkHub — mounted under /linkhub in the main Khan G server.
// This is a self-contained Express sub-app (own view engine, own static folder).
const express = require('express');
const path = require('path');
const session = require('express-session');
const MongoStore = require('connect-mongo');

const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const shortenerRoutes = require('./routes/shortener');
const publicRoutes = require('./routes/public');

function createLinkHubApp() {
  const app = express();

  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));

  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, 'public')));

  app.use(
    session({
      secret: process.env.SESSION_SECRET || 'change-this-secret-in-production',
      resave: false,
      saveUninitialized: false,
      store: process.env.MONGODB_URI
        ? MongoStore.create({ mongoUrl: process.env.MONGODB_URI })
        : undefined, // falls back to in-memory store if no Mongo URI (dev only)
      cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }, // 7 days
    })
  );

  app.get('/', (req, res) => res.render('home'));

  app.use('/', authRoutes);
  app.use('/', dashboardRoutes);
  app.use('/', shortenerRoutes);
  app.use('/', publicRoutes); // keep this LAST — it catches /:username

  app.use((req, res) => res.status(404).send('Page not found'));

  return app;
}

module.exports = createLinkHubApp;
