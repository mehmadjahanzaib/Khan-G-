# LinkHub — Link-in-Bio SaaS (Starter)

Ye ek simple "Link in Bio" app hai (jaisa Linktree). Users signup karke apni links
add kar sakte hain, aur unka public page `yoursite.com/username` pe show hota hai.

## Files kahan hain

```
linkhub/
├── server.js              ← main file, sab kuch yahan se start hota hai
├── config/db.js           ← MongoDB se connect karta hai
├── models/                ← database ke "tables" (User, Link)
├── routes/                ← app ka logic (signup, login, dashboard, public page)
├── middleware/auth.js     ← login check karta hai
├── views/                 ← HTML pages (EJS templates)
├── public/css/style.css   ← styling
└── .env.example           ← environment variables ka sample
```

## Step 1 — Local computer pe chalana

1. [Node.js](https://nodejs.org) install karein (agar pehle se nahi hai)
2. Terminal mein is folder ke andar jaake ye chalayein:

```bash
npm install
```

3. `.env.example` file ko copy karke naam `.env` rakhein, aur values fill karein:
   - `MONGODB_URI` — [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register) pe free account banayein, ek cluster banayein, aur connection string yahan paste karein
   - `SESSION_SECRET` — koi bhi random lamba text (e.g. `mySuperSecretKey123`)

4. App chalayein:

```bash
npm start
```

5. Browser mein `http://localhost:3000` kholein.

## Step 2 — Render pe deploy karna (free)

1. Is poore folder ko GitHub pe ek naye repository mein upload karein
2. [Render.com](https://render.com) pe free account banayein
3. "New +" → "Web Service" → apna GitHub repo select karein
4. Settings:
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
5. "Environment" tab mein wahi variables add karein jo `.env` mein thay
   (`MONGODB_URI`, `SESSION_SECRET`, `SITE_NAME`, `PORT`)
6. "Create Web Service" pe click karein — Render khud build karke deploy kar dega

Kuch minutes mein aapka app live URL mil jayega (e.g. `linkhub.onrender.com`).

## Abhi kya kaam karta hai (MVP)

- Signup / Login / Logout
- Dashboard se links add/delete karna
- Free plan: max 5 links
- Public page `/username` pe links dikhana
- Har link click track hota hai (clickCount)
- **URL Shortener** — dashboard se `/dashboard/shortener` pe jaake koi bhi lambi URL short kar sakte hain (e.g. `yoursite.com/s/aZ3kLm`), aur har short link ke clicks track hote hain

## Agay kya add kar sakte hain

- Password reset (forgot password)
- Themes/colors choose karna
- Paid plan ke liye payment integration (JazzCash/Easypaisa/Payoneer)
- Link reordering (drag & drop)
- Profile picture upload
