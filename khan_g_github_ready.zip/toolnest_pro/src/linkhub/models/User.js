// CREATE — stores each signed-up user
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      // only letters, numbers, underscore allowed — keeps URLs clean
      match: /^[a-z0-9_]+$/,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true, // stored as a bcrypt hash, never plain text
    },
    bio: {
      type: String,
      default: "",
    },
    theme: {
      type: String,
      default: "default", // IMPLEMENTATION ASSUMPTION: simple theme name for now
    },
    plan: {
      type: String,
      enum: ["free", "paid"],
      default: "free",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
