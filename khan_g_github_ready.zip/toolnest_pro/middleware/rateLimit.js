// Small in-memory per-IP rate limiter (no extra dependency needed).
// Good enough for a single-server deployment; resets if the process restarts.
function simpleRateLimit({ windowMs, max }) {
  const hits = new Map();

  setInterval(() => {
    const cutoff = Date.now() - windowMs;
    for (const [ip, timestamps] of hits) {
      const kept = timestamps.filter(t => t > cutoff);
      if (kept.length === 0) hits.delete(ip);
      else hits.set(ip, kept);
    }
  }, windowMs).unref();

  return function rateLimit(req, res, next) {
    const ip = req.ip || req.connection.remoteAddress || 'unknown';
    const now = Date.now();
    const windowStart = now - windowMs;
    const timestamps = (hits.get(ip) || []).filter(t => t > windowStart);

    if (timestamps.length >= max) {
      return res.status(429).json({ error: 'Too many requests. Please slow down and try again shortly.' });
    }

    timestamps.push(now);
    hits.set(ip, timestamps);
    next();
  };
}

module.exports = { simpleRateLimit };
