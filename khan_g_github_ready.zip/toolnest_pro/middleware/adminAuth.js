// Simple shared-secret guard for owner-only endpoints (viewing/deleting data
// that should not be public). Set ADMIN_KEY in your .env before deploying.
function requireAdmin(req, res, next) {
  const configuredKey = process.env.ADMIN_KEY;

  if (!configuredKey) {
    console.warn('ADMIN_KEY is not set — refusing admin-only request. Set ADMIN_KEY in your .env file.');
    return res.status(503).json({ error: 'Admin access is not configured on this server yet.' });
  }

  const providedKey = req.get('x-admin-key');
  if (providedKey && providedKey === configuredKey) {
    return next();
  }

  return res.status(401).json({ error: 'Unauthorized.' });
}

module.exports = { requireAdmin };
