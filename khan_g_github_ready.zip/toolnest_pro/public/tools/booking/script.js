const ALL_SLOTS = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];

const dateInput = document.getElementById('booking_date');
const timeSelect = document.getElementById('booking_time');
const form = document.getElementById('booking-form');
const messageBox = document.getElementById('form-message');
const submitBtn = document.getElementById('submit-btn');

// Don't allow picking a past date
const today = new Date().toISOString().split('T')[0];
dateInput.setAttribute('min', today);

function showMessage(text, type) {
  messageBox.textContent = text;
  messageBox.className = `form-message ${type}`;
  messageBox.hidden = false;
}

async function loadAvailableSlots(date) {
  timeSelect.innerHTML = '<option value="" disabled selected>Loading...</option>';
  try {
    const res = await fetch(`/tools/booking/api/bookings/taken/${date}`);
    const taken = await res.json();
    const available = ALL_SLOTS.filter(slot => !taken.includes(slot));

    timeSelect.innerHTML = '';
    if (available.length === 0) {
      timeSelect.innerHTML = '<option value="" disabled selected>No slots left for this date</option>';
      return;
    }
    timeSelect.innerHTML = '<option value="" disabled selected>Select a time</option>' +
      available.map(slot => `<option value="${slot}">${slot}</option>`).join('');
  } catch (err) {
    timeSelect.innerHTML = '<option value="" disabled selected>Could not load times</option>';
  }
}

dateInput.addEventListener('change', () => {
  if (dateInput.value) loadAvailableSlots(dateInput.value);
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  messageBox.hidden = true;
  submitBtn.disabled = true;
  submitBtn.textContent = 'Booking...';

  const payload = {
    name: document.getElementById('name').value.trim(),
    email: document.getElementById('email').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    service: document.getElementById('service').value,
    booking_date: document.getElementById('booking_date').value,
    booking_time: document.getElementById('booking_time').value,
    notes: document.getElementById('notes').value.trim(),
  };

  try {
    const res = await fetch('/tools/booking/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      showMessage(data.error || 'Something went wrong.', 'error');
    } else {
      showMessage('Booking confirmed! Check your email for details.', 'success');
      form.reset();
      timeSelect.innerHTML = '<option value="" disabled selected>Select date first</option>';
    }
  } catch (err) {
    showMessage('Could not connect to server. Try again.', 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Confirm booking';
  }
});
