const form = document.getElementById('countdown-form');
const messageBox = document.getElementById('form-message');
const submitBtn = document.getElementById('submit-btn');

function showMessage(text, type) {
  messageBox.textContent = text;
  messageBox.className = `form-message ${type}`;
  messageBox.hidden = false;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  messageBox.hidden = true;
  submitBtn.disabled = true;
  submitBtn.textContent = 'Creating...';

  const payload = {
    title: document.getElementById('title').value.trim(),
    target_datetime: document.getElementById('target_datetime').value,
    message: document.getElementById('message').value.trim(),
    theme: document.getElementById('theme').value,
  };

  try {
    const res = await fetch('/tools/countdown/api/countdowns', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      showMessage(data.error || 'Something went wrong.', 'error');
    } else {
      window.location.href = `view.html?slug=${data.slug}`;
    }
  } catch (err) {
    showMessage('Could not connect to server.', 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Create countdown page';
  }
});
