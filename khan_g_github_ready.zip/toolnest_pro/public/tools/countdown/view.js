const params = new URLSearchParams(window.location.search);
const slug = params.get('slug');
const page = document.getElementById('countdown-page');
const body = document.getElementById('view-body');

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function pad(n) {
  return String(n).padStart(2, '0');
}

let timerInterval;

function startTimer(targetDate) {
  function tick() {
    const now = new Date();
    const diff = targetDate - now;

    if (diff <= 0) {
      clearInterval(timerInterval);
      document.getElementById('timer-blocks').innerHTML = `<div class="over-message">It's here! 🎉</div>`;
      return;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((diff / (1000 * 60)) % 60);
    const seconds = Math.floor((diff / 1000) % 60);

    document.getElementById('t-days').textContent = pad(days);
    document.getElementById('t-hours').textContent = pad(hours);
    document.getElementById('t-minutes').textContent = pad(minutes);
    document.getElementById('t-seconds').textContent = pad(seconds);
  }
  tick();
  timerInterval = setInterval(tick, 1000);
}

async function loadCountdown() {
  if (!slug) {
    page.innerHTML = '<div class="empty-state">No countdown specified.</div>';
    return;
  }
  try {
    const res = await fetch(`/tools/countdown/api/countdowns/${slug}`);
    if (!res.ok) {
      page.innerHTML = '<div class="empty-state">This countdown doesn\'t exist.</div>';
      return;
    }
    const c = await res.json();
    body.className = `theme-${c.theme || 'forest'}`;

    page.innerHTML = `
      <div class="countdown-inner">
        <h1>${escapeHtml(c.title)}</h1>
        ${c.message ? `<p class="countdown-message">${escapeHtml(c.message)}</p>` : ''}
        <div id="timer-blocks" class="timer-blocks">
          <div class="timer-block"><span id="t-days">00</span><label>Days</label></div>
          <div class="timer-block"><span id="t-hours">00</span><label>Hours</label></div>
          <div class="timer-block"><span id="t-minutes">00</span><label>Minutes</label></div>
          <div class="timer-block"><span id="t-seconds">00</span><label>Seconds</label></div>
        </div>
      </div>
    `;

    startTimer(new Date(c.target_datetime));
  } catch (err) {
    page.innerHTML = '<div class="empty-state">Could not load countdown.</div>';
  }
}

loadCountdown();
