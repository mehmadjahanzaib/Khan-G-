const form = document.getElementById('expense-form');
const messageBox = document.getElementById('form-message');
const submitBtn = document.getElementById('submit-btn');
const expenseList = document.getElementById('expense-list');
const totalSpentEl = document.getElementById('total-spent');
const remainingEl = document.getElementById('remaining');
const progressFill = document.getElementById('progress-fill');
const progressNote = document.getElementById('progress-note');
const budgetInput = document.getElementById('budget-input');
const budgetSaveBtn = document.getElementById('budget-save');

document.getElementById('expense_date').valueAsDate = new Date();

function getAdminKey() {
  let key = localStorage.getItem('khang_admin_key');
  if (!key) {
    key = prompt('This is your personal expense tracker. Enter your admin key to unlock it:') || '';
    if (key) localStorage.setItem('khang_admin_key', key);
  }
  return key;
}

async function adminFetch(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { ...(options.headers || {}), 'x-admin-key': getAdminKey() },
  });
  if (res.status === 401) {
    localStorage.removeItem('khang_admin_key');
    showMessage('Wrong admin key. Refresh the page and try again.', 'error');
  }
  return res;
}

function rs(n) {
  return `Rs ${Number(n).toLocaleString('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

function showMessage(text, type) {
  messageBox.textContent = text;
  messageBox.className = `form-message ${type}`;
  messageBox.hidden = false;
}

async function loadBudgetAndSummary() {
  const [budgetRes, summaryRes] = await Promise.all([
    adminFetch('/tools/expenses/api/budget'),
    adminFetch('/tools/expenses/api/summary'),
  ]);
  const budget = await budgetRes.json();
  const summary = await summaryRes.json();

  budgetInput.value = budget.monthly_limit || '';
  totalSpentEl.textContent = rs(summary.total);

  const limit = budget.monthly_limit || 0;
  const remaining = limit - summary.total;
  remainingEl.textContent = rs(remaining);
  remainingEl.style.color = remaining < 0 ? '#B3432B' : '';

  if (limit > 0) {
    const pct = Math.min(100, (summary.total / limit) * 100);
    progressFill.style.width = `${pct}%`;
    progressFill.style.background = pct >= 100 ? '#B3432B' : pct >= 80 ? '#C9A24B' : '#2D5F4F';
    progressNote.textContent = pct >= 100
      ? 'Budget se zyada kharch ho gaya hai.'
      : `${pct.toFixed(0)}% of your budget used.`;
  } else {
    progressFill.style.width = '0%';
    progressNote.textContent = 'Set a monthly budget to track your progress.';
  }
}

async function loadExpenses() {
  const res = await adminFetch('/tools/expenses/api/expenses');
  const expenses = await res.json();

  if (expenses.length === 0) {
    expenseList.innerHTML = '<div class="empty-state">Koi expense abhi tak add nahi hui.</div>';
    return;
  }

  expenseList.innerHTML = expenses.slice(0, 20).map(e => `
    <div class="expense-row">
      <div class="expense-info">
        <span class="expense-desc">${escapeHtml(e.description)}</span>
        <span class="expense-meta">${escapeHtml(e.category)} · ${e.expense_date}</span>
      </div>
      <span class="expense-amount">${rs(e.amount)}</span>
      <button class="delete-btn" onclick="deleteExpense(${e.id})">&times;</button>
    </div>
  `).join('');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function deleteExpense(id) {
  await adminFetch(`/tools/expenses/api/expenses/${id}`, { method: 'DELETE' });
  await Promise.all([loadExpenses(), loadBudgetAndSummary()]);
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  messageBox.hidden = true;
  submitBtn.disabled = true;
  submitBtn.textContent = 'Adding...';

  const payload = {
    description: document.getElementById('description').value.trim(),
    category: document.getElementById('category').value,
    amount: document.getElementById('amount').value,
    expense_date: document.getElementById('expense_date').value,
  };

  try {
    const res = await adminFetch('/tools/expenses/api/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      showMessage(data.error || 'Something went wrong.', 'error');
    } else {
      form.reset();
      document.getElementById('expense_date').valueAsDate = new Date();
      await Promise.all([loadExpenses(), loadBudgetAndSummary()]);
    }
  } catch (err) {
    showMessage('Could not connect to server.', 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Add expense';
  }
});

budgetSaveBtn.addEventListener('click', async () => {
  const value = budgetInput.value;
  if (value === '' || Number(value) < 0) return;
  await adminFetch('/tools/expenses/api/budget', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ monthly_limit: Number(value) }),
  });
  loadBudgetAndSummary();
});

loadExpenses();
loadBudgetAndSummary();
