const params = new URLSearchParams(window.location.search);
const slug = params.get('slug');
const container = document.getElementById('card-container');

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function initials(name) {
  return name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
}

function buildVCard(c) {
  return [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `FN:${c.name}`,
    c.title ? `TITLE:${c.title}` : '',
    c.company ? `ORG:${c.company}` : '',
    c.email ? `EMAIL:${c.email}` : '',
    c.phone ? `TEL:${c.phone}` : '',
    c.website ? `URL:${c.website}` : '',
    'END:VCARD',
  ].filter(Boolean).join('\n');
}

function downloadVCard(c) {
  const blob = new Blob([buildVCard(c)], { type: 'text/vcard' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${c.name.replace(/\s+/g, '_')}.vcf`;
  a.click();
  URL.revokeObjectURL(url);
}

async function loadCard() {
  if (!slug) {
    container.innerHTML = '<div class="empty-state">No card specified.</div>';
    return;
  }
  try {
    const res = await fetch(`/tools/card/api/cards/${slug}`);
    if (!res.ok) {
      container.innerHTML = '<div class="empty-state">This card doesn\'t exist.</div>';
      return;
    }
    const c = await res.json();

    container.innerHTML = `
      <div class="business-card">
        <div class="bc-avatar">${initials(c.name)}</div>
        <h1>${escapeHtml(c.name)}</h1>
        ${c.title || c.company ? `<p class="bc-role">${escapeHtml(c.title)}${c.title && c.company ? ' · ' : ''}${escapeHtml(c.company)}</p>` : ''}
        ${c.bio ? `<p class="bc-bio">${escapeHtml(c.bio)}</p>` : ''}
        <div class="bc-links">
          ${c.email ? `<a href="mailto:${escapeHtml(c.email)}">${escapeHtml(c.email)}</a>` : ''}
          ${c.phone ? `<a href="tel:${escapeHtml(c.phone)}">${escapeHtml(c.phone)}</a>` : ''}
          ${c.website ? `<a href="https://${escapeHtml(c.website.replace(/^https?:\/\//, ''))}" target="_blank" rel="noopener">${escapeHtml(c.website)}</a>` : ''}
          ${c.linkedin ? `<a href="https://${escapeHtml(c.linkedin.replace(/^https?:\/\//, ''))}" target="_blank" rel="noopener">${escapeHtml(c.linkedin)}</a>` : ''}
        </div>
        <button id="save-contact" class="save-btn">Save to contacts</button>
      </div>
    `;

    document.getElementById('save-contact').addEventListener('click', () => downloadVCard(c));
  } catch (err) {
    container.innerHTML = '<div class="empty-state">Could not load card.</div>';
  }
}

loadCard();
