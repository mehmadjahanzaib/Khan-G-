const form = document.getElementById('card-form');
const messageBox = document.getElementById('form-message');
const submitBtn = document.getElementById('submit-btn');

function showMessage(text, type) {
  messageBox.textContent = text;
  messageBox.className = `form-message ${type}`;
  messageBox.hidden = false;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  messageBox.hidden = true;
  submitBtn.disabled = true;
  submitBtn.textContent = 'Creating...';

  const payload = {
    name: document.getElementById('name').value.trim(),
    title: document.getElementById('title').value.trim(),
    company: document.getElementById('company').value.trim(),
    email: document.getElementById('email').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    website: document.getElementById('website').value.trim(),
    linkedin: document.getElementById('linkedin').value.trim(),
    bio: document.getElementById('bio').value.trim(),
  };

  try {
    const res = await fetch('/tools/card/api/cards', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      showMessage(data.error || 'Something went wrong.', 'error');
    } else {
      window.location.href = `view.html?slug=${data.slug}`;
    }
  } catch (err) {
    showMessage('Could not connect to server.', 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Create my card';
  }
});
